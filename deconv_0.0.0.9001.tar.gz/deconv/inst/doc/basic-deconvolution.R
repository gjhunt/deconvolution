## ----warning=FALSE-------------------------------------------------------
suppressPackageStartupMessages(library("affy"))
rat.url <- "ftp://ftp.ncbi.nlm.nih.gov/geo/series/GSE19nnn/GSE19830/suppl/GSE19830_RAW.tar"
rat.dir <- "rat_data"
dir.create(rat.dir, showWarnings = FALSE)
rat.file <- "rat.tar"
download.file(rat.url, destfile = rat.file)
untar(rat.file, exdir = rat.dir)
rat <- ReadAffy(celfile.path = rat.dir)

## ----echo=FALSE,results='hide'-------------------------------------------
file.remove(rat.file)
file.remove(paste(rat.dir,dir(rat.dir),sep="/"))
unlink(rat.dir,force=TRUE,recursive=TRUE)

## ------------------------------------------------------------------------
rat.truth = matrix(c(0,0,0,1,1,1,0,0,0,0.25,0.25,0.25,0.05,0.05,0.05,0.7,0.7,0.7,0.25,0.25,0.25,0.45,0.45,0.45,0.2,0.2,0.2,0.3,0.3,0.3,0.3,0.3,0.3,0.4,0.4,0.4,0.35,0.35,0.35,0.34,0.34,0.34,1,1,1,0,0,0,0,0,0,0.05,0.05,0.05,0.7,0.7,0.7,0.25,0.25,0.25,0.7,0.7,0.7,0.45,0.45,0.45,0.55,0.55,0.55,0.5,0.5,0.5,0.55,0.55,0.55,0.5,0.5,0.5,0.6,0.6,0.6,0.65,0.65,0.65,0,0,0,0,0,0,1,1,1,0.7,0.7,0.7,0.25,0.25,0.25,0.05,0.05,0.05,0.05,0.05,0.05,0.1,0.1,0.1,0.25,0.25,0.25,0.2,0.2,0.2,0.15,0.15,0.15,0.1,0.1,0.1,0.05,0.05,0.05,0.01,0.01,0.01),ncol=3,byrow=FALSE)
head(rat.truth)

## ------------------------------------------------------------------------
pure_samples <- lapply(1:3, function(i) {
    which(rat.truth[, i] == 1)
})
pure_samples

## ----results='hide',echo=FALSE-------------------------------------------
library('affy')

## ------------------------------------------------------------------------
Y <- log2(t(affy::intensity(rat)))
Y[1:4,1:4]

## ------------------------------------------------------------------------
library('deconv')
n_choose <- 250
dc <- deconv(Y, pure_samples, n_choose)
phats <- dc$estimates
head(phats)

## ----results='asis',fig.height=5,fig.width=5-----------------------------
plot(rat.truth,phats,xlab="Truth",ylab="Estimates")
abline(coef=c(0,1))

## ----warning=FALSE,results='hide'----------------------------------------
Y <- data.frame(affy::rma(rat,verbose=FALSE))

n_choose <- 100
dc <- deconv(Y, pure_samples, n_choose)
phats <- dc$estimates

## ----results='asis',fig.height=5,fig.width=5-----------------------------
plot(rat.truth,phats,xlab="Truth",ylab="Estimates")
abline(coef=c(0,1))

