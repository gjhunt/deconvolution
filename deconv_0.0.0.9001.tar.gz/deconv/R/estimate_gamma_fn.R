#' Estimate slope gamma.
#' 
#' @return The estimated slope.
est_gamma <- function() {
    return(0.7)
}
